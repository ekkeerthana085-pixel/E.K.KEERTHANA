import { Heart, Leaf, Sun } from 'lucide-react';

export default function AboutUs({ onShop }) {
  return (
    <main className="page-wrap">
      <section className="about-hero">
        <div className="about-copy">
          <span className="section-kicker">A LITTLE ABOUT US</span>
          <h1 className="page-title">Life is better<br />with a little green.</h1>
          <p>Paradise Nursery began with a simple idea: everyone deserves a space that feels alive. We bring together thoughtfully selected houseplants that help make everyday spaces feel calmer, warmer, and more personal.</p>
          <p>Whether you're caring for your very first plant or adding to a home jungle, we're here to help you find a plant that fits your space and your life.</p>
          <button className="primary-button" onClick={onShop}>Find your plant <span>→</span></button>
        </div>
        <img className="about-image" src="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=1000&q=85" alt="A collection of leafy indoor plants" />
      </section>
      <section className="values-grid" aria-label="Our values">
        <article className="value-card"><Leaf size={25} /><h3>Thoughtfully grown</h3><p>We celebrate the beauty of plants and choose varieties that bring character and life into your home.</p></article>
        <article className="value-card"><Heart size={25} /><h3>Care in every detail</h3><p>From choosing your plant to learning its care routine, we want your growing journey to feel simple.</p></article>
        <article className="value-card"><Sun size={25} /><h3>Room to flourish</h3><p>We believe a little greenery can make a big difference to the feeling of a room.</p></article>
      </section>
    </main>
  );
}