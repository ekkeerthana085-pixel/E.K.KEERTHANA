# Paradise Nursery

Paradise Nursery is a responsive plant shop demo built with React, Vite, Redux Toolkit, and CSS.

## Features
- Landing page with a Get Started button
- About Us page
- Plant catalog with category filters
- Add plants to cart
- Increase/decrease item quantity and remove items
- Cart subtotal and item count
- Responsive layout for mobile and desktop

## Run locally
1. Install Node.js (LTS).
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown in the terminal.

## Main files
- `src/App.jsx` — page layout and navigation
- `src/App.css` — styling and landing-page background image
- `src/components/AboutUs.jsx` — company information
- `src/components/ProductList.jsx` — plant listing page
- `src/components/CartItem.jsx` — shopping cart page
- `src/features/cart/CartSlice.jsx` — Redux cart reducers

## Note
This is a learning project. Product images are loaded from Unsplash URLs and therefore require an internet connection.
