import { useDispatch, useSelector } from 'react-redux';
import { ArrowLeft, Minus, Plus, ShoppingCart, Trash2 } from 'lucide-react';
import { removeItem, updateQuantity, clearCart } from '../features/cart/CartSlice.js';

const money = (amount) => `$${amount.toFixed(2)}`;

export default function CartItem({ onContinue, onShop }) {
  const dispatch = useDispatch();
  const items = useSelector((state) => state.cart.items);
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <main className="page-wrap">
      <button className="nav-link" onClick={onContinue} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
        <ArrowLeft size={16} /> Continue browsing
      </button>
      <span className="section-kicker">YOUR LITTLE INDOOR JUNGLE</span>
      <h1 className="page-title">Shopping cart<span style={{ color: '#8ba181' }}>.</span></h1>
      <p className="page-intro">A little green is on its way. Review your plants below.</p>

      {items.length === 0 ? (
        <section className="empty-cart" style={{ marginTop: 30 }}>
          <div className="empty-cart-icon"><ShoppingCart size={26} /></div>
          <h2>Your cart is waiting to grow.</h2>
          <p>You haven't added any plants yet. Your next favorite might be just a leaf away.</p>
          <button className="primary-button" onClick={onShop}>Explore plants <span>→</span></button>
        </section>
      ) : (
        <div className="cart-layout">
          <section className="cart-list" aria-label="Items in your cart">
            {items.map((item) => (
              <article className="cart-row" key={item.id}>
                <img className="cart-row-image" src={item.image} alt={item.name} />
                <div>
                  <span className="product-category">{item.category}</span>
                  <h2 className="cart-item-name">{item.name}</h2>
                  <div className="cart-unit-price">{money(item.price)} each</div>
                  <div className="quantity-controls" aria-label={`Quantity controls for ${item.name}`}>
                    <button className="quantity-button" aria-label={`Decrease ${item.name} quantity`} onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity - 1 }))}><Minus size={14} /></button>
                    <span className="quantity-number" aria-live="polite">{item.quantity}</span>
                    <button className="quantity-button" aria-label={`Increase ${item.name} quantity`} onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }))}><Plus size={14} /></button>
                  </div>
                  <button className="remove-button" onClick={() => dispatch(removeItem(item.id))}><Trash2 size={13} /> Remove</button>
                </div>
                <div className="cart-line-total">{money(item.price * item.quantity)}</div>
              </article>
            ))}
            <button className="remove-button" onClick={() => dispatch(clearCart())} style={{ alignSelf: 'flex-start', marginTop: 4 }}>Clear entire cart</button>
          </section>
          <aside className="summary-card">
            <h2>Order summary</h2>
            <div className="summary-line"><span>Items ({totalQuantity})</span><span>{money(subtotal)}</span></div>
            <div className="summary-line"><span>Delivery</span><span>Calculated at checkout</span></div>
            <div className="summary-line summary-total"><span>Subtotal</span><span>{money(subtotal)}</span></div>
            <button className="primary-button" onClick={() => window.alert('Thanks for trying Paradise Nursery! This demo does not process real payments.')}>Continue to checkout <span>→</span></button>
            <p className="summary-note">Demo checkout only. No payment will be collected.</p>
          </aside>
        </div>
      )}
    </main>
  );
}