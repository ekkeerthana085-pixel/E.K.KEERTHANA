import { useState } from 'react';
import { Leaf, ShoppingCart, Sprout } from 'lucide-react';
import AboutUs from './components/AboutUs.jsx';
import ProductList from './components/ProductList.jsx';
import CartItem from './components/CartItem.jsx';

export default function App() {
  const [page, setPage] = useState('home');
  const [returnPage, setReturnPage] = useState('products');

  const openCart = () => {
    setReturnPage(page === 'cart' ? returnPage : page);
    setPage('cart');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goTo = (nextPage) => {
    setPage(nextPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="app-shell">
      {page !== 'home' && (
        <header className="site-header">
          <button className="brand brand-button" onClick={() => goTo('home')} aria-label="Go to home">
            <span className="brand-mark"><Leaf size={22} /></span>
            <span>paradise<span className="brand-light">nursery</span></span>
          </button>
          <nav className="main-nav" aria-label="Main navigation">
            <button className={page === 'products' ? 'nav-link active' : 'nav-link'} onClick={() => goTo('products')}>Plants</button>
            <button className={page === 'about' ? 'nav-link active' : 'nav-link'} onClick={() => goTo('about')}>About Us</button>
          </nav>
          <button className="cart-nav" onClick={openCart} aria-label="Open shopping cart">
            <ShoppingCart size={20} /><span>Cart</span>
          </button>
        </header>
      )}

      {page === 'home' && (
        <main className="hero">
          <div className="hero-overlay" />
          <div className="hero-top">
            <button className="brand hero-brand" onClick={() => goTo('home')}>
              <span className="brand-mark"><Leaf size={22} /></span>
              <span>paradise<span className="brand-light">nursery</span></span>
            </button>
            <button className="hero-about" onClick={() => goTo('about')}>Our story</button>
          </div>
          <div className="hero-content">
            <span className="eyebrow"><Sprout size={15} /> GROW A LITTLE HAPPINESS</span>
            <h1>Make room<br />for <em>something</em><br />green.</h1>
            <p>Thoughtfully chosen plants to make your space feel more like you. Find your new favorite leaf.</p>
            <button className="primary-button hero-cta" onClick={() => goTo('products')}>Get Started <span>→</span></button>
            <div className="hero-note"><span className="note-line" /> GOOD THINGS GROW HERE</div>
          </div>
          <div className="hero-bottom">
            <span>PLANTS FOR EVERY SPACE</span><span>ROOTED IN GOOD LIVING · EST. 2024</span>
          </div>
        </main>
      )}

      {page === 'products' && <ProductList onOpenCart={openCart} />}
      {page === 'about' && <AboutUs onShop={() => goTo('products')} />}
      {page === 'cart' && <CartItem onContinue={() => goTo(returnPage === 'home' || returnPage === 'cart' ? 'products' : returnPage)} onShop={() => goTo('products')} />}
      <footer className="site-footer">
        <div className="footer-brand"><Leaf size={18} /> Paradise Nursery</div>
        <span>Bring home a little green.</span>
        <span>Made with care for plant people.</span>
      </footer>
    </div>
  );
}